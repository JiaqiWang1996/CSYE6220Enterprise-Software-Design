package com.me.dao;

import com.me.pojo.Movie;

public class MovieDAO extends DAO{
	public void addMovie(Movie movie) {
		beginTransaction();
		getSession().save(movie);
		commit();
	}
	
	public Movie searchMovie(int id) {
		beginTransaction();
		Movie movie = getSession().get(Movie.class, id);
		commit();
		return movie;
	}
	
	public void updateMovie(Movie movie) {
		beginTransaction();
		getSession().update(movie);
		commit();
	}
	
	public void deleteMovie(Movie movie) {
		beginTransaction();
		getSession().delete(movie);
		commit();
	}

}
