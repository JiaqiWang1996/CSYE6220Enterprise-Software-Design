package com.me.controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.me.dao.MovieDAO;
import com.me.pojo.Movie;

@Controller
public class MovieController {
    @RequestMapping(value="/movie/add.htm", method=RequestMethod.GET)
	public ModelAndView addMovie(MovieDAO movieDao) {
            Movie movie = new Movie();
            movie.setMovieTitle("Movie Title");
            movie.setLeadActor("Actor");
            movie.setLeadActress("Actress");
            movie.setGenre("Genre");
            movie.setYear(2020);
            
//            MovieDAO movieDao = new MovieDAO();
            movieDao.addMovie(movie);
            return new ModelAndView("success", "successMessage","Movie added successfully!");
	}
        
    	@RequestMapping(value="/movie/search.htm", method=RequestMethod.GET)
        public ModelAndView searchMovie(MovieDAO movieDao){
            Movie movie = movieDao.searchMovie(1);
            return new ModelAndView("movie-view","movie",movie);
        }
        
    	@RequestMapping(value="/movie/update.htm", method=RequestMethod.GET)
        public ModelAndView updateMovie(MovieDAO movieDao){
            Movie movie = movieDao.searchMovie(48);
            movie.setMovieTitle("Updated Title");
            movieDao.updateMovie(movie);
            return new ModelAndView("success", "successMessage","Movie updated successfully!");
        }
        
    	@RequestMapping(value="/movie/delete.htm", method=RequestMethod.GET)
        public ModelAndView deleteMovie(MovieDAO movieDao) {
    		Movie movie = movieDao.searchMovie(48);
            if(movie != null){
				//delete movie
                movieDao.deleteMovie(movie);
            }
            return new ModelAndView("success", "successMessage","Movie deleted successfully!");
        }
    
}