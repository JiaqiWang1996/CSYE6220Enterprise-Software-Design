/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.DAO;

import com.mycompany.exception.AdException;
import com.mycompany.pojo.Advert;
import com.mycompany.pojo.User;
import org.hibernate.HibernateException;

/**
 *
 * @author dedhi
 */
public class AdvertDAO extends DAO {

    public Advert create(String title, String message, User user) throws AdException {
        try {
            begin();
            Advert advert = new Advert(title, message, user);
            getSession().save(advert);
            commit();
            return advert;
        } catch (HibernateException e) {
            rollback();
            //throw new AdException("Could not create advert", e);
            throw new AdException("Exception while creating advert: " + e.getMessage());
        }
    }

    public void delete(Advert advert) throws AdException {
        try {
            begin();
            getSession().delete(advert);
            commit();
        } catch (HibernateException e) {
            rollback();
            throw new AdException("Could not delete advert", e);
        }
    }
}