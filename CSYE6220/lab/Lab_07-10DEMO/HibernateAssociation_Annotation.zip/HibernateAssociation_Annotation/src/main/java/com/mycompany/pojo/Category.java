/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pojo;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.*;

/**
 *
 * @author dedhi
 */
@Entity
@Table(name = "tbl_category")
public class Category {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long id;

    @Basic
    @Column(name="title")
    private String title;
    
    @ManyToMany
    @JoinTable(name = "link_category_advert", joinColumns = @JoinColumn( name="category"), inverseJoinColumns = @JoinColumn( name="advert"))
    private Set<Advert> adverts = new HashSet();

    public Category() {
    }
    
    public Category(String title) {
        this.title = title;
        this.adverts = new HashSet();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Set getAdverts() {
        return adverts;
    }

    public void setAdverts(Set adverts) {
        this.adverts = adverts;
    }
    
    public void addAdvert(Advert advert) {
        getAdverts().add(advert);
    }
}
