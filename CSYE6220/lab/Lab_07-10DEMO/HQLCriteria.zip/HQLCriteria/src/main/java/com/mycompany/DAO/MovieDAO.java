/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.DAO;

import com.mycompany.pojo.Movie;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;

/**
 *
 * @author dedhi
 */
public class MovieDAO extends DAO{
    //Get all movies using HQL
    public List<Movie> getMovieList(){
        beginTransaction();
        String hql = "FROM Movie";
        Query query = getSession().createQuery(hql);
        List results = query.list();
        commit();
        return results;
    }
    
    //Filter movies as per actor using HQL
    public List<Movie> filterActor(String actor){
        beginTransaction();
        String hql = "FROM Movie where actor = :actor";
        Query query = getSession().createQuery(hql);
        query.setParameter("actor", actor);
        List results = query.list();
        commit();
        return results;
    }
    
    //Filter movies as per actress using Criteria
    public List<Movie> filterActress(String actress){
        beginTransaction();
        Criteria criteria = getSession().createCriteria(Movie.class);
        criteria.add(Restrictions.eq("leadActress", actress));
        List<Movie> results = criteria.list();
        return results;
    }
    
}
