/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.controller;

import com.mycompany.DAO.MovieDAO;
import com.mycompany.pojo.Movie;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author dedhi
 */
@Controller
public class MovieController {
    @GetMapping("/movies.htm")
    public ModelAndView getMovieList(MovieDAO movieDao){
        List<Movie> movieList = movieDao.getMovieList();
        return new ModelAndView("movies-view","movies",movieList);
    }
    
    @GetMapping("/movies/filter-actor.htm")
    public ModelAndView filterActor(MovieDAO movieDao){
        List<Movie> movieList = movieDao.filterActor("Liam Neeson");
        return new ModelAndView("movies-view","movies",movieList);
    }
    
    @GetMapping("/movies/filter-actress.htm")
    public ModelAndView filterActress(MovieDAO movieDao){
        List<Movie> movieList = movieDao.filterActress("Maggie Grace");
        return new ModelAndView("movies-view","movies",movieList);
    }
}
