/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.controller;

import com.mycompany.pojo.Movie;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author dedhi
 */
@Controller
public class MovieController {
    @GetMapping("/movie/add.htm")
	public ModelAndView addMovie() {
            Movie movie = new Movie();
            movie.setMovieTitle("Movie Title");
            movie.setLeadActor("Actor");
            movie.setLeadActress("Actress");
            movie.setGenre("Genre");
            movie.setYear(2020);
            
            //Hibernate
            Configuration cfg = new Configuration();
            SessionFactory sf = cfg.configure("hibernate.cfg.xml").buildSessionFactory();
            Session session = sf.openSession();
            Transaction tx = session.beginTransaction();
            //add movie object in database
            session.save(movie);
            
            tx.commit();
            session.close();
            return new ModelAndView("success", "successMessage","Movie added successfully!");
	}
        
        @GetMapping("/movie/search.htm")
        public ModelAndView searchMovie(){
            Configuration cfg = new Configuration();
            SessionFactory sf = cfg.configure("hibernate.cfg.xml").buildSessionFactory();
            Session session = sf.openSession();
            Transaction tx = session.beginTransaction();
            //get movie object from database with movieId = 1
            Movie movie = session.get(Movie.class, 1);
            tx.commit();
            session.close();
            return new ModelAndView("movie-view","movie",movie);
        }
        
        @GetMapping("/movie/update.htm")
        public ModelAndView updateMovie(){
            Configuration cfg = new Configuration();
            SessionFactory sf = cfg.configure("hibernate.cfg.xml").buildSessionFactory();
            Session session = sf.openSession();
			//get movie object from database with movieId = 35
            Movie movie = session.get(Movie.class, 35);
            movie.setMovieTitle("Title");
            Transaction tx = session.beginTransaction();
			//update movie
            session.update(movie);
            
            tx.commit();
            session.close();
            return new ModelAndView("success", "successMessage","Movie updated successfully!");
        }
        
        @GetMapping("/movie/delete.htm")
        public ModelAndView deleteMovie() {
     
            Configuration cfg = new Configuration();
            SessionFactory sf = cfg.configure("hibernate.cfg.xml").buildSessionFactory();
            Session session = sf.openSession();
            Movie movie = session.get(Movie.class, 37);
            Transaction tx = session.beginTransaction();
            if(movie != null){
				//delete movie
                session.delete(movie);
            }
            
            
            tx.commit();
            session.close();
            return new ModelAndView("success", "successMessage","Movie deleted successfully!");
        }
    
}
