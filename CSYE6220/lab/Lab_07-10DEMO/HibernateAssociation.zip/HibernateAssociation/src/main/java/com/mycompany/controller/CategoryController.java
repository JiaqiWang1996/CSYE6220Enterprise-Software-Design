/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.controller;

import com.mycompany.DAO.CategoryDAO;
import com.mycompany.DAO.DAO;
import com.mycompany.exception.AdException;
import com.mycompany.pojo.Category;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author dedhi
 */
@Controller
public class CategoryController {
    @GetMapping("/addcategory.htm")
    public String displayAddControllerForm(Model model, Category category){
        return "addCategoryForm";
    }
    
    @PostMapping("/addcategory.htm")
    public ModelAndView addController(@ModelAttribute("category") Category newCategory, BindingResult result, SessionStatus status){
        try
        {
            CategoryDAO category = new CategoryDAO();
            category.create(newCategory.getTitle());
            DAO.close();
            status.setComplete();
            return new ModelAndView("addCategorySuccess","category",newCategory);
        }
        catch (AdException e)
        {
            System.out.println("Exception: " + e.getMessage());
        }
        return null;
    }
    
}
