/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.controller;

import com.mycompany.DAO.AdvertDAO;
import com.mycompany.DAO.CategoryDAO;
import com.mycompany.DAO.DAO;
import com.mycompany.DAO.UserDAO;
import com.mycompany.exception.AdException;
import com.mycompany.pojo.Advert;
import com.mycompany.pojo.Category;
import com.mycompany.pojo.User;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author dedhi
 */
@Controller
public class AdvertController {
    @GetMapping("/addadvert.htm")
    public ModelAndView displayAddAdvertForm(Model model, Advert advert) throws AdException{
       CategoryDAO categoryDao = new CategoryDAO();
       List<Category> categories = categoryDao.list();
        System.out.println("categories: "+categories);
        return new ModelAndView("addAdvertForm","categories", categories);
    }
    
    @PostMapping("/addadvert.htm")
    public ModelAndView addAdvert(@ModelAttribute("advert") Advert newAdvert, BindingResult result, SessionStatus status){
        String username = newAdvert.getPostedBy();   //get posting user from addAdvertForm
        String categoryTitle = newAdvert.getCategory();   //get category user from addAdvertForm
        String title = newAdvert.getTitle();      //get advert title user from addAdvertForm
        String message = newAdvert.getMessage();    //get user message from addAdvertForm

        try {
            UserDAO users = new UserDAO();
            CategoryDAO categories = new CategoryDAO();
            AdvertDAO adverts = new AdvertDAO();

            //searching from database
            User user = users.get(username);

            //searching from database
            Category category = categories.get(categoryTitle);

            //insert a new advert
            Advert advert = adverts.create(title, message, user);

            category.addAdvert(advert);
            categories.save(category);

            DAO.close();
            
            status.setComplete();
            return new ModelAndView("addAdvertSuccess","advert",newAdvert);
        } catch (AdException e) {
            System.out.println(e.getMessage());
        }
        return null;  
    }
    
    @GetMapping("/listadverts.htm")
    public ModelAndView listAdverts(){
        CategoryDAO categories = null;
        List<Category> categoryList = null;
        List advList = new ArrayList();
        try {
            categories = new CategoryDAO();
            categoryList = categories.list();
            Iterator categIterator = categoryList.iterator();
            while (categIterator.hasNext())
            {
                Category category = (Category) categIterator.next();
                Iterator advIterator = category.getAdverts().iterator();
                while (advIterator.hasNext())
                {
                    Advert advert = (Advert) advIterator.next();
                    advList.add(advert);
                }
            }
            DAO.close();
        } catch (AdException e) {
            System.out.println(e.getMessage());
        }
        ModelAndView mv = new ModelAndView("viewAdverts", "adverts", advList);
//        ModelAndView mv = new ModelAndView("viewAdverts", "categories", categoryList);
        return mv;
    }
    
}
