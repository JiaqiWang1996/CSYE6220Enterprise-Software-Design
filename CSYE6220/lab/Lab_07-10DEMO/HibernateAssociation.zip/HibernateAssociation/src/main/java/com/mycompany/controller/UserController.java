/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.controller;

import com.mycompany.DAO.UserDAO;
import com.mycompany.exception.AdException;
import com.mycompany.pojo.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author dedhi
 */
@Controller
public class UserController {
    
    @GetMapping("/adduser.htm")
    public String displayAddUserForm(Model model, User user){
        return "addUserForm";
    }
    
    @PostMapping("/adduser.htm")
    public ModelAndView addUser(@ModelAttribute("user") User newUser, BindingResult result, SessionStatus status){
        try
        {
            UserDAO userDao = new UserDAO();
            userDao.create(newUser.getName(), newUser.getPassword());
            userDao.close();
            status.setComplete();
            return new ModelAndView("addUserSuccess","user",newUser);
        }
        catch (AdException e)
        {
            System.out.println("Exception: " + e.getMessage());
        }
        return null;
    }
}
