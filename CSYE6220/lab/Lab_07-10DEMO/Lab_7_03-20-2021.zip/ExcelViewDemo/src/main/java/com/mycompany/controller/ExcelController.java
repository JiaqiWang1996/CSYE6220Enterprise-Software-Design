/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.controller;

import com.mycompany.view.ExcelView;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.View;

/**
 *
 * @author dedhi
 */
@Controller
public class ExcelController {
     @RequestMapping(value="/report.xls", method=RequestMethod.GET)
    protected View handleRequest(){
        View view = new ExcelView();
        return view;
//        return new ModelAndView(view);
    }
    
}
