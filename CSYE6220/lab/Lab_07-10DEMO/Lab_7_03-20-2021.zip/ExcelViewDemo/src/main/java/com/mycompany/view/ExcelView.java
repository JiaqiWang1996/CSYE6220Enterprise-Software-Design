/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.view;

import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsView;


/**
 *
 * @author dedhi
 */
public class ExcelView extends AbstractXlsView{

    @Override
    protected void buildExcelDocument(Map<String, Object> map, Workbook workbook, HttpServletRequest hsr, HttpServletResponse hsr1) throws Exception {
        Sheet sheet = workbook.createSheet("Sheet One");
        Row row1 = sheet.createRow(0);
        Cell cell10 = row1.createCell(0);
        cell10.setCellValue("First Name");
        Cell cell11 = row1.createCell(1);
        cell11.setCellValue("Last Name");
        Row row2 = sheet.createRow(1);
        Cell cell20 = row2.createCell(0);
        cell20.setCellValue("Dimpi");
        Cell cell21 = row2.createCell(1);
        cell21.setCellValue("Dedhia");
    }
    
}
