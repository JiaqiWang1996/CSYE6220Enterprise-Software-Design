/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.view;

import com.lowagie.text.*;
import com.lowagie.text.Header;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.Color;
import java.net.URL;
import java.util.Map;
import javafx.scene.layout.Border;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.view.document.AbstractPdfView;

/**
 *
 * @author dedhi
 */
public class PdfView extends AbstractPdfView{

    @Override
    protected void buildPdfDocument(Map<String, Object> map, Document doc, PdfWriter writer, HttpServletRequest hsr, HttpServletResponse hsr1) throws Exception {
        //Create an element and add the element in the doc

         Paragraph para = new Paragraph("Personal Information",FontFactory.getFont(FontFactory.TIMES_ROMAN, 40, Font.BOLD, new Color(255, 0,0)));  
         para.setAlignment(1);
         doc.add(para);
         Table table = new Table(2);
         Image image = Image.getInstance("C:\\Users\\dedhi\\Docs\\Dimpi.jpeg");
         Cell cell1 = new Cell(image);
         cell1.setRowspan(4);
         table.addCell(cell1);
         Chunk name = new Chunk("Name: Dimpi Pankaj Dedhia", FontFactory.getFont(FontFactory.TIMES_ROMAN, 20));
         Chunk age = new Chunk("Age: 25 years",FontFactory.getFont(FontFactory.TIMES_ROMAN, 20));
         Chunk address = new Chunk("Address: Boston, MA, USA",FontFactory.getFont(FontFactory.TIMES_ROMAN, 20));
         Chunk contact = new Chunk("Contact no.: 866-890-1234",FontFactory.getFont(FontFactory.TIMES_ROMAN, 20));
         Cell cellname = new Cell(name);
         Cell cellage = new Cell(age);
         Cell celladdress = new Cell(address);
         Cell cellcontact = new Cell(contact);
         table.addCell(cellname);
         table.addCell(cellage);
         table.addCell(celladdress);
         table.addCell(cellcontact);
         table.setPadding(5);
         table.setAlignment(Element.ALIGN_LEFT);
         cell1.setBorderWidth(0);
         cellname.setBorderWidth(0);
         cellage.setBorderWidth(0);
         celladdress.setBorderWidth(0);
         cellcontact.setBorderWidth(0);
         cellname.setWidth(50);
         table.setBorderWidth(0);
         table.setWidth(100);
         doc.add(table);
//         String imageFile = "C:\\Users\\dedhi\\Docs\\Dimpi.jpeg"; 
         
    }
    
}
